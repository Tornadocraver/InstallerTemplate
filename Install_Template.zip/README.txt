﻿***************************************************
 -- // Copyright (c) Tornadoenterprises 2016 \\ --
***************************************************
    -- Developers: Micah V. (TornadoHackerz) --
___________________________________________________

- You may customize the basic GUI to your likings and add any additional actions to the code.
- Please read the LICENSE AGREEMENT for use of this template (specifically #2-6), as well a incrporating in your software.
- Current forms are located in the 'Pages' folder.

File Instructions:

	1. Please include any .dll's that your program could not package.
		Path: {assembly-name}.InstallationFiles.Dlls
	2. Please include any external classes that your program depends on.
		Path: {assembly-name}.InstallationFiles.Classes
	3. Please include any external executable files that your program depends on.
		Path: {assembly-name}.InstallationFiles.Exeutables
		Additional: You MUST name the the RELEASE version of your program to: 'MAINEXE.exe' Once copied, this file will take on the name of the current assembly.
	4. Please change the Build Action property of ALL EXTERNAL files to: 'Embedded Resource'

- Please Note: All these files will be copied to the output directory. 
- Also, this program is intended for use with executable files (.exe). 
	- Any other format you WILL have to incorporate yourself.

If you have any questions or comments, please email me at:
	micahmail9@gmail.com
and use the subject:
	Install Template Feedback

Happy Coding!

	~Micah